$(document).ready(function(){
  			//$('.imgtag').maphilight({fillColor: '3598DB'});
			$('#region').html('<h2 class="noselect">Sélectionnez une wilaya pour afficher les agences locales</h2>');
			 var wilaya; 
			 var moveLeft = 20;
			 var moveDown = 10;
				//alert('bigo');
				$('area').hover(function(e){
					//alert('popi');
					wilayaid=$(this).attr('id');
					wilaya=$(this).attr('title');
					$('.wilaya').html(wilaya);
					$('div#pop-up').show().css('top', e.pageY+moveDown)
								   .css('left', e.pageX+moveLeft)
								   .appendTo('body');
					$('area').css('background', 'red')
				}, function() {$('div#pop-up').hide();
				});
				
				$("area").click(function(e){
		     			//$('.imgtag').maphilight();
						wilaya=$(this).attr('title');
						$('.wilayaheader').html('<h1 class="bluecard">'+wilaya+'</h1>');
						//$('.wilayaheader').append('<hr width="30px"/>');

						var prefix=$("#dbprefix").text();
						
						$.get("../index.php?option=com_m2imapselector&view=ajax&format=ajax&wilaya="+wilayaid).done(function(response){
							//$("#region").html(response);
							if (response=='[]')
							{
								$('#region').html('Aucune Agence trouvée dans cette wilaya!');
							}
							else
							{
									$('#region').html('');
									$.each($.parseJSON(response), function(key,value){
										$('#region').append('<h2 class="bluecard">'+value.code+'-'+value.agence+'</h2>');
										$('#region').append('<div class="bluecard" id="descrparaph"><h3 id="nolinehead" class="addresspb"><span class="fa fa-map-marker"></span>&nbsp;</h3><p id="descrparaphp"> '+value.address+'</p></div><br/>');
										$('#region').append('<h3 class="bluecard" id="nolinehead"><span class="fa fa-phone" aria-hidden="true"></span>&nbsp;</h3> '+value.phone+'<br/>');
										$('#region').append('<h3 class="bluecard" id="nolinehead"><span class="fa fa-fax"></span>&nbsp;</h3> '+value.fax+'<br/>');
										if((jQuery.trim( value.description )).length != 0) 
											$('#region').append('<h3 class="bluecard" id="nolinehead"><span class="fa fa-envelope"></span>&nbsp;</h3> '+value.description+'<br/>');
										$('#region').append('<hr id="agenceline" />');
									});
							}
						});
				});
 
				/*$('.land').click(function(e) {
						$(this).data('maphilight', { 
							alwaysOn: true 
						}).trigger('alwaysOn.maphilight');
						//check if area wasnt already selected - otherwise gets buggy
						if( !$(this).hasClass('selected') ){ 
							$('.selected').data('maphilight', {
							alwaysOn: false
						}).trigger('alwaysOn.maphilight');
						$('#map-tag area').removeClass('selected');
						$(this).addClass('selected');
					}
				});*/
				
				var nice = $("#region").niceScroll();  // The document page (body)

				
				
				
		 var basic_opts = {
					mapKey: 'title'
		};

		var initial_opts = $.extend({},basic_opts, 
		{ 
			//staticState: true,
			//fillColor: '00ff00',        
			//stroke: true,
			//strokeWidth: 0,
			strokeColor: '3598DB'
		});

		$('.imgtag').mapster(initial_opts)
			.mapster('set',true,'', {
			fill: false,
			//fillColor: 'FF0000'
		})
		.mapster('snapshot')
		.mapster('rebind',basic_opts);
		
		$('.land').click(function(e) {
				wilaya=$(this).attr('title');
				$('.imgtag').mapster(initial_opts)
			.mapster('set',true,wilaya, {
			fill: true,
			fillColor: '3598DB'
		})
		.mapster('snapshot')
		.mapster('rebind',basic_opts);
		});
		
		/*$('.land').hover(function(e) {
				wilaya=$(this).attr('title');
				$('.imgtag').mapster(initial_opts)
			.mapster('set',true,wilaya, {
			fill: true,
			fillColor: '00ff00'
		})
		.mapster('snapshot')
		.mapster('rebind',basic_opts);
		});*/
});

					
