<h1>Agence selectionée : </h1>

<p><b>ID sur la table :</b> <?php	echo $_POST['id'];?></p>
<p><b>Nom de l'agence : </b> <?php	echo $_POST['agence'];?></p>
<p><b>Wilaya : </b> <?php	echo $_POST['wilaya'];?></p>
<p><b>Adresse : </b>  <?php	echo $_POST['address'];?></p>
<p><b>Email : </b> <?php	echo $_POST['description'];?></p>
<p><b>Téléphone : </b> <?php	echo $_POST['phone'];?></p>
<p><b>Fax : </b> <?php	echo $_POST['fax'];?></p>
<p><b>Code : </b> <?php	echo $_POST['code'];?></p>

<h4>Modifier la description de cette agence : </h4>
<form action="" method="post">
	Sélectioner une Wilaya :<br>
	<select name="wilayalist">
<option value="Adrar" >Adrar</option><!--1-->
		<option value="Chlef">Chlef</option><!--2-->
		<option value="Laghouat">Laghouat</option><!--3-->
		<option value="Oum el Bouaghi">Oum el Bouaghi</option><!--4-->
		<option value="Batna" >Batna</option><!--5-->
		<option value="Bejaia">Béjaïa</option><!--6-->
		<option value="Biskra">Biskra</option><!--7-->
		<option value="Bechar">Béchar</option><!--8-->
		<option value="Blida" >Blida</option><!--9-->
		<option value="Bouira">Bouira</option><!--10-->
		<option value="Tamanghasset">Tamanghasset</option><!--11-->
		<option value="Tebessa">Tébessa</option><!--12-->
		<option value="Tlemcen" >Tlemcen</option><!--13-->
		<option value="Tiaret">Tiaret</option><!--14-->
		<option value="Tizi Ouzou">Tizi Ouzou</option><!--15-->
		<option value="Alger" selected>Alger</option><!--16-->
		<option value="Djelfa" >Djelfa</option><!--17-->
		<option value="Jijel">Jijel</option><!--18-->
		<option value="Setif">Sétif</option><!--19-->
		<option value="Saida">Saïda</option><!--20-->
		<option value="Skikda" >Skikda</option><!--21-->
		<option value="Sidi Bel Abbes">Sidi Bel Abbès</option><!--22-->
		<option value="Annaba">Annaba</option><!--23-->
		<option value="Guelma">Guelma</option><!--24-->
		<option value="Constantine" >Constantine</option><!--25-->
		<option value="Medea">Médéa</option><!--26-->
		<option value="Mostaganem">Mostaganem</option><!--27-->
		<option value="Msila">Msila</option><!--28-->
		<option value="Mascara" >Mascara</option><!--29-->
		<option value="Ouargla">Ouargla</option><!--30-->
		<option value="Oran">Oran</option><!--31-->
		<option value="El Bayadh">El Bayadh</option><!--32-->
		<option value="Illizi" >Illizi</option><!--33-->
		<option value="Bordj Bou Arréridj">Bordj Bou Arréridj</option><!--34-->
		<option value="Boumerdes">Boumerdès</option><!--35-->
		<option value="El Tarf">El Tarf</option><!--36-->
		<option value="Tindouf" >Tindouf</option><!--37-->
		<option value="Tissemsilt">Tissemsilt</option><!--38-->
		<option value="El Oued">El Oued</option><!--39-->
		<option value="Khenchela">Khenchela</option><!--40-->
		<option value="Souk Ahras" >Souk Ahras</option><!--41-->
		<option value="Tipaza">Tipaza</option><!--42-->
		<option value="Mila">Mila</option><!--43-->
		<option value="Aïn Defla">Aïn Defla</option><!--44-->
		<option value="Naama" >Naama</option><!--45-->
		<option value="Ain Temouchent">Aïn Témouchent</option><!--46-->
		<option value="Ghardaia">Ghardaïa</option><!--47-->
		<option value="Oum el Bouaghi">Relizane</option><!--48-->	</select> 

    <input type="hidden" name="form_modif_finished_id" value="<?php echo $_POST['id']?>">
	<p> Nom de l'agence :<br/>
		<textarea rows="1" cols="32" name="agence"><?php echo $_POST['agence'];?></textarea>
	</p>
	<p> Adresse :<br/>
		<textarea rows="1" cols="32" name="address"><?php echo $_POST['address'];?></textarea>
	</p>
	<p> Email :<br/>
		<textarea rows="1" cols="32" name="description"><?php echo $_POST['description'];?></textarea>
	</p>
	<p> Téléphone :<br/>
		<textarea rows="1" cols="32" name="phone"><?php echo $_POST['phone'];?></textarea>
	</p>
	<p> Fax :<br/>
		<textarea rows="1" cols="32" name="fax"><?php echo $_POST['fax'];?></textarea>
	</p>
	<p> Code :<br/>
		<textarea rows="1" cols="32" name="code"><?php echo $_POST['code'];?></textarea>
	</p>
	
	<input type="submit" class="formButton" value="Valider">
</form>
<form action="" method="post">
   <input type="submit" class="formButton return" value="Annuler">
</form>

