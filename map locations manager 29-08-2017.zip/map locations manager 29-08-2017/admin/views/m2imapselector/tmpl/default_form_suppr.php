<h1>Agence sélectionée :</h1>

<p><b>ID sur la table :</b> <?php	echo $_POST['id'];?></p>
<p><b>Nom de l'agence : </b> <?php	echo $_POST['agence'];?></p>
<p><b>Code : </b> <?php	echo $_POST['code'];?></p>
<p><b>Wilaya : </b> <?php	echo $_POST['wilaya'];?></p>
<p><b>Adresse : </b>  <?php	echo $_POST['address'];?></p>
<p><b>Email : </b> <?php	echo $_POST['description'];?></p>
<p><b>Téléphone : </b> <?php	echo $_POST['phone'];?></p>
<p><b>Fax : </b> <?php	echo $_POST['fax'];?></p>


<h4>Êtes vous sûr de vouloir supprimer cette agence ?</h4>
<form action="" method="post">
    <input type="hidden" name="form_suppr_finished_id" value="<?php echo $_POST['id']?>">
	<input type="submit" class="formButton delete" value="Supprimer">
</form>
<form action="" method="post">
   <input type="submit" class="formButton return" value="Annuler">
</form>
