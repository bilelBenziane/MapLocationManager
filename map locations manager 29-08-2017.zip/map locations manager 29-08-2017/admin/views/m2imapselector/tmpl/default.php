<?php
defined('_JEXEC') or die('Restricted access');
$rows=$this->msg; //recuperer le resultat du getMsg du model
?>
<h1>Ajouter une nouvelle agence</h1>
<form action="" method="post">
    <input type="hidden" name="form_insert_new_element" value="">
	<input type="submit" class="formButton add" value="Ajouter">
</form>

<h1>La liste des agences</h1>
<br>
<p>Choisissez un filtre</P>
<form action="" method="post">
	<select name="wilayalist">
		<option value="Adrar" >Adrar</option><!--1-->
		<option value="Chlef">Chlef</option><!--2-->
		<option value="Laghouat">Laghouat</option><!--3-->
		<option value="Oum el Bouaghi">Oum el Bouaghi</option><!--4-->
		<option value="Batna" >Batna</option><!--5-->
		<option value="Bejaia">Béjaïa</option><!--6-->
		<option value="Biskra">Biskra</option><!--7-->
		<option value="Bechar">Béchar</option><!--8-->
		<option value="Blida" >Blida</option><!--9-->
		<option value="Bouira">Bouira</option><!--10-->
		<option value="Tamanghasset">Tamanrasset</option><!--11-->
		<option value="Tebessa">Tébessa</option><!--12-->
		<option value="Tlemcen" >Tlemcen</option><!--13-->
		<option value="Tiaret">Tiaret</option><!--14-->
		<option value="Tizi Ouzou">Tizi Ouzou</option><!--15-->
		<option value="Alger" selected>Alger</option><!--16-->
		<option value="Djelfa" >Djelfa</option><!--17-->
		<option value="Jijel">Jijel</option><!--18-->
		<option value="Setif">Sétif</option><!--19-->
		<option value="Saida">Saïda</option><!--20-->
		<option value="Skikda" >Skikda</option><!--21-->
		<option value="Sidi Bel Abbes">Sidi Bel Abbès</option><!--22-->
		<option value="Annaba">Annaba</option><!--23-->
		<option value="Guelma">Guelma</option><!--24-->
		<option value="Constantine" >Constantine</option><!--25-->
		<option value="Medea">Médéa</option><!--26-->
		<option value="Mostaganem">Mostaganem</option><!--27-->
		<option value="Msila">Msila</option><!--28-->
		<option value="Mascara" >Mascara</option><!--29-->
		<option value="Ouargla">Ouargla</option><!--30-->
		<option value="Oran">Oran</option><!--31-->
		<option value="El Bayadh">El Bayadh</option><!--32-->
		<option value="Illizi" >Illizi</option><!--33-->
		<option value="Bordj Bou Arréridj">Bordj Bou Arréridj</option><!--34-->
		<option value="Boumerdes">Boumerdès</option><!--35-->
		<option value="El Tarf">El Tarf</option><!--36-->
		<option value="Tindouf" >Tindouf</option><!--37-->
		<option value="Tissemsilt">Tissemsilt</option><!--38-->
		<option value="El Oued">El Oued</option><!--39-->
		<option value="Khenchela">Khenchela</option><!--40-->
		<option value="Souk Ahras" >Souk Ahras</option><!--41-->
		<option value="Tipaza">Tipaza</option><!--42-->
		<option value="Mila">Mila</option><!--43-->
		<option value="Aïn Defla">Aïn Defla</option><!--44-->
		<option value="Naama" >Naama</option><!--45-->
		<option value="Ain Temouchent">Aïn Témouchent</option><!--46-->
		<option value="Ghardaia">Ghardaïa</option><!--47-->
		<option value="Oum el Bouaghi">Relizane</option><!--48-->
	</select> 
	<input type="submit" class="formButton" value="Filtrer">
</form>

<table class="heavyTable">
	<thead>
		<tr>
		<?php 
			if(isset($_POST['wilayalist']))
			{
				echo '<th>ID</th>' ;
				echo '<th>Agence</th>';
				echo '<th>Wilaya</th>' ;
				echo '<th>Email</th>' ;
				echo '<th>Adresse</th>' ;
				echo '<th>Téléphone</th>' ;
				echo '<th>Fax</th>' ;
				echo '<th>Code</th>' ;
				echo '<th>Modification</th>' ;
				echo '<th>Suppression</th>' ;

			}
		?>
		</tr>
	</thead>
    <tbody>
		<?php 
			if(isset($_POST['wilayalist']))
			{
				foreach ($rows as $row) {
					if($row['wilaya']==$_POST['wilayalist'])
					{   
						echo '<tr>';
						echo '<td >'.$row['id'].'</td>';
						echo '<td >'.$row['agence'].'</td>';
						echo '<td >'.$row['wilaya'].'</td>';
						echo '<td >'.$row['description'].'</td>';
						echo '<td >'.$row['address'].'</td>';
						echo '<td >'.$row['phone'].'</td>';
						echo '<td >'.$row['fax'].'</td>';
						echo '<td >'.$row['code'].'</td>';
					
						echo '<td >'.'<form action="" method="post">';
						echo '<input type="hidden" value="'.$row['id'].'" name="id"/>';
						echo '<input type="hidden" value="modif" name="actionms"/>';
						echo '<input type="hidden" value="'.$row['agence'].'" name="agence"/>';
						echo '<input type="hidden" value="'.$row['wilaya'].'" name="wilaya"/>';
						echo '<input type="hidden" value="'.$row['description'].'" name="description"/>';
						echo '<input type="hidden" value="'.$row['address'].'" name="address"/>';
						echo '<input type="hidden" value="'.$row['phone'].'" name="phone"/>';
						echo '<input type="hidden" value="'.$row['code'].'" name="code"/>';
						echo '<input type="hidden" value="'.$row['fax'].'" name="fax"/>';
						echo '<input type="submit" class="buttontab" value="Modifier"/>';
						echo '</form>'.'</td>';
						
						echo '<td >'.'<form action="" method="post">';
						echo '<input type="hidden" value="'.$row['id'].' "name="id"/>';
						echo '<input type="hidden" value="suppr" name="actionms"/>';
						echo '<input type="hidden" value="'.$row['agence'].'" name="agence"/>';
						echo '<input type="hidden" value="'.$row['wilaya'].'" name="wilaya"/>';
						echo '<input type="hidden" value="'.$row['description'].'" name="description"/>';
						echo '<input type="hidden" value="'.$row['address'].'" name="address"/>';
						echo '<input type="hidden" value="'.$row['phone'].'" name="phone"/>';
						echo '<input type="hidden" value="'.$row['fax'].'" name="fax"/>';
						echo '<input type="hidden" value="'.$row['code'].'" name="code"/>';
						echo '<input type="submit" class="buttontab" value="Supprimer"/>';
						echo '</form>'.'</td>';

						
						echo '</tr>';
					}
				}	
		
				
			}
		?>

</tbody>
</table>

<table class="heavyTable">
	<thead>
		<tr>
		<?php 
			if(!isset($_POST['wilayalist']))
			{
				echo '<th>ID</th>' ;
				echo '<th>Agence</th>';
				echo '<th>Wilaya</th>' ;
				echo '<th>Email</th>' ;
				echo '<th>Adresse</th>' ;
				echo '<th>Téléphone</th>' ;
				echo '<th>Fax</th>' ;
				echo '<th>Code</th>' ;
				echo '<th>Modification</th>' ;
				echo '<th>Suppression</th>' ;

			}
		?>
		</tr>
	</thead>
    <tbody>
		<?php 
			if(!isset($_POST['wilayalist']))
			{
				foreach ($rows as $row) {
						echo '<tr>';
							echo '<td >'.$row['id'].'</td>';
							echo '<td >'.$row['agence'].'</td>';
							echo '<td >'.$row['wilaya'].'</td>';
							echo '<td >'.$row['description'].'</td>';
							echo '<td >'.$row['address'].'</td>';
							echo '<td >'.$row['phone'].'</td>';
							echo '<td >'.$row['fax'].'</td>';
							echo '<td >'.$row['code'].'</td>';
				
							
							echo '<td >'.'<form action="" method="post">';
							echo '<input type="hidden" value="'.$row['id'].'" name="id"/>';
							echo '<input type="hidden" value="modif" name="actionms"/>';
							echo '<input type="hidden" value="'.$row['agence'].'" name="agence"/>';
							echo '<input type="hidden" value="'.$row['wilaya'].'" name="wilaya"/>';
							echo '<input type="hidden" value="'.$row['description'].'" name="description"/>';
							echo '<input type="hidden" value="'.$row['address'].'" name="address"/>';
							echo '<input type="hidden" value="'.$row['phone'].'" name="phone"/>';
							echo '<input type="submit" class="buttontab" value="Modifier"/>';
							echo '<input type="hidden" value="'.$row['fax'].'" name="fax"/>';
							echo '<input type="hidden" value="'.$row['code'].'" name="code"/>';
							echo '</form>'.'</td>';
						
							echo '<td >'.'<form action="" method="post">';
							echo '<input type="hidden" value="'.$row['id'].'" name="id"/>';
							echo '<input type="hidden" value="suppr" name="actionms"/>';
							echo '<input type="hidden" value="'.$row['agence'].'" name="agence"/>';
							echo '<input type="hidden" value="'.$row['wilaya'].'" name="wilaya"/>';
							echo '<input type="hidden" value="'.$row['description'].'" name="description"/>';
							echo '<input type="hidden" value="'.$row['address'].'" name="address"/>';
							echo '<input type="hidden" value="'.$row['phone'].'" name="phone"/>';
							echo '<input type="hidden" value="'.$row['fax'].'" name="fax"/>';
							echo '<input type="hidden" value="'.$row['code'].'" name="code"/>';
							echo '<input type="submit" class="buttontab" value="Supprimer"/>';
							echo '</form>'.'</td>';
							
						echo '</tr>';
				}	
		
			}
		?>
		

</tbody>
</table>