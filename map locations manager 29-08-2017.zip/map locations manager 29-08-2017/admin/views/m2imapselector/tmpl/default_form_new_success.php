<h3 class="success">Nouvelle agence ajoutée</h3>
<p>Retour à l'écran principal</p>
<form action="" method="post">
     <input type="submit" value="Retour" class="formButton return"/>
</form>

<h1>Ajouter une nouvelle agence </h1>
<form action="" method="post">
    <input type="hidden" name="form_insert_new_element" value="">
	<input type="submit" class="formButton add" value="Ajouter">
</form>
