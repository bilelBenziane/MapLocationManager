
<h3 class="success">Suppression réussie</h3>
<p>Retour à l'écran principal</p>
<form action="" method="post">
     <input type="submit" value="Retour" class="formButton return"/>
</form>