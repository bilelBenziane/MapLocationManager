<?php
defined('_JEXEC') or die('Restricted access');

class M2iMapSelectorViewM2iMapSelector extends JViewLegacy
{
	function display($tpl = null)
	{
		
		$doc = JFactory::getDocument();
		$doc->addStyleSheet(JURI :: root().'media/com_m2imapselector/css/style.css');		
		
		JToolBarHelper::Title("La liste des agences");
		$this->msg = $this->get('Msg');
		if (count($errors = $this->get('Errors')))
		{
			JLog::add(implode('<br />', $errors), JLog::WARNING, 'jerror');
			return false;
		}

		if(isset($_POST['actionms']) && $_POST['actionms']=="modif"){//pour passer les parametre a le for du modifications
			$tpl="form";
    		parent::display($tpl);
		}else if(isset($_POST['form_modif_finished_id'])){
   		  $tpl="form_success";
    	  parent::display($tpl);
		  $email=$_POST['description'];
		  $email=str_replace(' ', '', $email);
		  $model= $this->getModel();
		  echo $model->setMsg($_POST['form_modif_finished_id'],$_POST['agence'],$_POST['address'],$email,$_POST['phone'],$_POST['wilayalist'],$_POST['fax'],$_POST['code']);
		}else if(isset($_POST['actionms']) && $_POST['actionms']=="suppr"){
			$tpl="form_suppr";
    		parent::display($tpl);
		}else if(isset($_POST['form_suppr_finished_id'])){
   		  $tpl="form_suppr_success";
    	  parent::display($tpl);
		  $model= $this->getModel();
		  $model->setMsgSuppr($_POST['form_suppr_finished_id']);
		}else if(isset($_POST['form_insert_new_element'])){
   		  $tpl="form_new_element";
    	  parent::display($tpl);
		}else if(isset($_POST['agence_new']) && isset($_POST['wilayalist'])){
   		  $tpl="form_new_success";
    	  parent::display($tpl);
		  $model= $this->getModel();
		  $model->setMsgNew($_POST['wilayalist'],$_POST['agence_new'],$_POST['address_new'],$_POST['description_new'],$_POST['phone_new'],$_POST['fax_new'],$_POST['code_new']);
		}
		
		
		else{
			parent::display($tpl);
		}
	}
}
?>