<?php
defined('_JEXEC') or die('Restricted access');
class Event {
	public $id;
	public $sale;
	public $seance;
	public $jour;
	public $description;
}

class Agence {
	public $id;
	public $agence;
	public $address;
	public $phone;
	public $description;
	public $wilaya;
	public $fax;
	public $code;
}
class M2iMapSelectorModelM2iMapSelector extends JModelItem
{
	protected $message;
	public function getMsg()
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query->select('*');
		$query->from($db->quoteName('#__agencies'));
		$db->setQuery($query);
		$rows=$db->loadAssocList();
		if (!isset($this->message))
			return $rows;
	} 
	public function setMsg($id, $agence1,$address,$description,$phone,$wilayalist,$fax,$code)
	{
		$agence=new Agence();
		$agence->id=$id;
		$agence->description=$description;
		$agence->agence=$agence1;
		$agence->address=$address;
		$agence->phone=$phone;
		$agence->wilaya=$wilayalist;
		$agence->fax=$fax;
		$agence->code=$code;
		$result =JFactory::getDbo()->updateObject('#__agencies',$agence,'id');
		return "";
	}
	
	public function setMsgSuppr($id)
	{
	$db = JFactory::getDbo();
	$query = $db->getQuery(true);

	// delete all custom keys for user 1001.
		$conditions = array(
		$db->quoteName('id') . '='.$id);

		$query->delete($db->quoteName('#__agencies'));
		$query->where($conditions);
	
		$db->setQuery($query);

		$result = $db->execute();	
		return "";
	}
	public function setMsgNew($wilaya1,$agence1,$address1,$description1,$phone1,$fax1,$code1)
	{
		$agence=new Agence();
		$agence->description=$description1;
		$agence->agence=$agence1;
		$agence->address=$address1;
		$agence->phone=$phone1;
		$agence->wilaya=$wilaya1;
		$agence->fax=$fax1;
		$agence->code=$code1;
		$result =JFactory::getDbo()->insertObject('#__agencies',$agence,'id');
		return "";
	}
}
?>

