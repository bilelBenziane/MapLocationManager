<?php
defined('_JEXEC') or die('Restricted access');
class M2iMapSelectorController extends JControllerLegacy
{

}
?>