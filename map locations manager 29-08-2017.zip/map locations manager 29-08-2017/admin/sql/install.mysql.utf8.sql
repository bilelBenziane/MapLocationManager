CREATE TABLE IF NOT EXISTS `#__agencies` (
	`id` int(10) NOT NULL AUTO_INCREMENT,
	`wilaya` varchar(25) NOT NULL,
	`agence` varchar(25) NOT NULL,
	`description` varchar(100) NOT NULL,
	`address` varchar(100) NOT NULL,
	`phone` varchar(100) NOT NULL,
	`code` varchar(20) NOT NULL,
	`fax` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=INNODB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;

