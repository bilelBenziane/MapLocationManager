<?php
defined('_JEXEC') or die('Restricted access');

class M2iMapSelectorModelAjax extends JModelItem{//this class is a model for the jQuery ajax to get agencies of a specific wilaya
	
	protected $message;

	public function getAgencies($wilaya)//this function is used to get the agencies in a wilaya in json format
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query->select('*');
		$query->from($db->quoteName('#__agencies'));
		$query->where($db->quoteName('wilaya')." = ".$db->quote($wilaya));
		$db->setQuery($query);
		$rows=$db->loadAssocList();
		if (!isset($this->message))
			return $rows;
	}
}
?>