<?php
defined('_JEXEC') or die('Restricted access');

class M2iMapSelectorModelM2iMapSelector extends JModelItem{
	
}
?>