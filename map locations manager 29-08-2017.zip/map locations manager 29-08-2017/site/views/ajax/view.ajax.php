<?php
 
defined( '_JEXEC' ) or die( 'Restricted access' );
 
jimport( 'joomla.application.component.view');

class M2iMapSelectorViewAjax extends JViewLegacy {


    function display($tpl = null)
	{
	   $model= $this->getModel();
       $rows=$model->getAgencies($_GET['wilaya']); 
	   echo json_encode($rows);
	}
 
}