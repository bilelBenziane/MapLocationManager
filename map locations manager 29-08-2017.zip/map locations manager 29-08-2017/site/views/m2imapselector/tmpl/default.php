<?php
	defined('_JEXEC') or die('Restricted access');
?>
<div id="mapheaddiv">
	<h1 class="bluecard">TROUVER UNE AGENCE</h1>
</div>
<div id="containerhello" >
		<div id="mapwrap" >
			<map name="im" width="320" height="320" id="maptag">
    <!--00-->	<area  class="land" shape="poly" coords="108,58,119,56,122,48,120,40,111,38,108,36,106,39,99,39,106,46,108,58" id="Tlemcen" title="Tlemcen" href="#mapheaddiv" />
				<area  class="land" shape="poly" coords="120,40,126,35,121,33,116,30,110,36,114,38,119,40" id="Ain Temouchent" title="Aïn Témouchent" href="#mapheaddiv"/>
				<area  class="land" shape="poly" coords="127,34,133,30,133,27,128,25,124,29,119,28,117,30,122,34,126,34" id="Oran" title="Oran" href="#mapheaddiv" />
				<area  class="land" shape="poly" coords="134,29,139,30,143,25,148,21,145,16,137,20,132,26,133,28" id="Mostaganem" title="Mostaganem" href="#mapheaddiv" />
				<area  class="land" shape="poly" coords="157,26,160,24,162,26,160,19,161,12,151,13,146,16,149,22,156,26" id="Chlef" title="Chlef" href="#mapheaddiv" />
				<area  class="land" shape="poly" coords="161,16,168,15,175,15,171,11,163,11,161,15" id="Tipaza" href="#mapheaddiv" title="Tipaza" />
				<area  class="land" shape="poly" coords="171,11,175,14,179,12,183,11,187,11,186,7,180,7,172,11" id="Alger" title="Alger" href="#mapheaddiv" />
				<area  class="land" shape="poly" coords="185,7,188,12,195,11,198,6,193,5,189,8,186,7" id="Boumerdes" title="Boumerdès" href="#mapheaddiv" />
				<area  class="land" shape="poly" coords="192,12,197,15,203,15,207,11,207,6,204,6,199,5,196,9,192,12" id="Tizi Ouzou" title="Tizi Ouzou" href="#mapheaddiv" />
				<area  class="land" shape="poly" coords="211,13,206,19,203,19,203,15,207,10,208,6,213,8,220,10,221,14,216,16,212,12,210,13" id="Bejaia" title="Béjaïa" href="#mapheaddiv" />
	<!--10-->	<area  class="land" shape="poly" coords="218,9,223,14,230,13,236,12,232,4,229,7,223,7,220,9" id="Jijel" title="Jijel" href="#mapheaddiv" />
				<area  class="land" shape="poly" coords="231,3,234,8,237,11,240,11,243,15,248,10,249,5,246,3,241,5,236,3" id="Skikda" title="Skikda" href="#mapheaddiv" />
				<area  class="land" shape="poly" coords="249,11,248,2,253,4,256,7,254,12,249,12,249,7" id="Annaba" title="Annaba" href="#mapheaddiv" />
				<area  class="land" shape="poly" coords="257,7,258,6,268,4,265,12,259,14,256,12" href="#mapheaddiv" title="El Tarf" id="El Tarf" />
				<area  class="land" shape="poly" coords="264,14,259,14,255,19,250,19,249,23,254,27,258,27,263,24,265,13" id="Souk Ahras" title="Souk Ahras" href="#mapheaddiv" />
				<area  class="land" shape="poly" coords="244,22,244,15,249,12,256,12,258,15,256,19,250,21,244,22" id="Guelma" title="Guelma" href="#mapheaddiv" />
				<area  class="land" shape="poly" coords="237,21,234,16,239,12,245,17,244,21,238,20" id="Constantine" title="Constantine" href="#mapheaddiv" />
				<area  class="land" shape="poly" coords="237,21,230,26,226,15,233,13,238,11,237,16" id="Mila" title="Mila" href="#mapheaddiv" />
				<area  class="land" shape="poly" coords="219,31,214,28,217,20,210,18,211,13,217,15,223,14,228,21,230,25,223,26"  id="Setif" title="Sétif" href="#mapheaddiv" />
				<area  class="land" shape="poly" coords="214,28,210,26,205,28,204,23,198,23,203,19,206,19,210,17,217,20,215,23" id="Bordj Bou Arreridj" title="Bordj Bou Arréridj" href="#mapheaddiv" />
	<!--20-->	<area  class="land" shape="poly" coords="188,12,194,13,197,15,203,15,201,20,198,25,193,26,189,23,192,19" href="#mapheaddiv" title="Bouira" id="Bouira" />
				<area  class="land" shape="poly" coords="188,11,181,11,176,13,175,16,180,17,185,17,188,14" href="#mapheaddiv" id="Blida" title="Blida"/>
				<area  class="land" shape="poly" coords="188,15,192,19,189,22,191,29,187,28,184,30,180,26,179,32,172,33,170,29,172,25,175,22,176,16" id="Medea" title="Médéa" href="#mapheaddiv" />
				<area  class="land" shape="poly" coords="174,25,175,20,175,15,166,15,161,16,161,22,163,26,166,27,168,24" id="Ain Defla" title="Aïn Defla" href="#mapheaddiv" />
				<area  class="land" shape="poly" coords="169,32,171,29,172,25,169,24,166,27,161,25,157,25,155,28,156,32,163,32,169,33" id="Tissemsilt" title="Tissemsilt"  href="#mapheaddiv" />
				<area  class="land" shape="poly" coords="150,34,155,30,157,25,152,24,148,21,143,26,139,30,144,33" id="Relizane" title="Relizane" href="#mapheaddiv" />
				<area  class="land" shape="poly" coords="150,34,144,32,139,32,134,29,128,33,132,36,133,40,138,42,143,42,144,38" id="Mascara"  title="Mascara" href="#mapheaddiv" />
				<area  class="land" shape="poly" coords="131,42,133,40,132,37,128,33,120,40,122,46,119,56,123,57,127,56,129,62,133,59,136,57,135,53,131,46" id="Sidi Bel Abbes"  title="Sidi Bel Abbès" href="#mapheaddiv" />
				<area  class="land" shape="poly" coords="136,53,133,48,131,46,132,41,135,41,139,43,143,41,147,42,146,46,148,50,151,53,141,53" href="#mapheaddiv"  id="Saida" title="Saïda"/>
				<area  class="land" shape="poly" coords="157,60,151,54,145,45,149,43,143,39,152,33,156,31,166,33,171,37,176,37,176,42,173,44,172,49,162,53" id="Tiaret" title="Tiaret" href="#mapheaddiv" />
	<!--30-->	<area  class="land" shape="poly" coords="193,34,190,31,187,29,185,31,181,28,179,33,173,34,170,32,167,34,171,38,177,38,174,44,172,51,178,61,183,57,184,62,194,71,201,79,212,83,214,70,202,64,196,48,191,42,192,36" id="Djelfa" title="Djelfa" href="#mapheaddiv" />
				<area  class="land" shape="poly" coords="200,57,195,47,190,42,193,33,186,29,190,29,189,25,196,27,202,22,206,27,211,27,214,29,217,31,210,33,210,39,214,42,212,46,204,46,200,51" id="Msila" title="Msila" href="#mapheaddiv" />
				<area  class="land" shape="poly" coords="231,25,236,28,240,28,242,31,237,37,238,43,237,46,234,41,228,42,226,37,221,40,215,42,212,41,211,33,217,33,223,27,227,26" id="Batna" title="Batna" href="#mapheaddiv" />
				<area  class="land" shape="poly" coords="230,25,237,21,243,20,249,22,253,26,257,29,253,34,248,31,243,32,238,28" href="#mapheaddiv" id="Oum el Bouaghi" title="Oum el Bouaghi" />
				<area  class="land" shape="poly" coords="264,25,258,26,253,27,258,30,254,34,249,35,251,40,247,43,250,45,246,58,251,60,255,57,257,52,263,49,263,41,266,38,264,31" id="Tebessa" title="Tébessa" href="#mapheaddiv" />
				<area  class="land" shape="poly" coords="253,32,249,35,251,41,247,43,250,45,247,58,242,58,239,55,240,47,238,44,237,38,240,33,245,32" id="Khenchela" title="Khenchela" href="#mapheaddiv" />
				<area  class="land" shape="poly" coords="238,55,239,46,235,46,233,41,227,43,225,37,213,42,212,47,202,46,200,51,200,55,200,62,212,70,216,72,217,64,217,61,216,52,234,54" id="Biskra" title="Biskra" href="#mapheaddiv" />
				<area  class="land" shape="poly" coords="219,71,217,57,216,53,222,53,237,54,241,57,251,60,252,66,255,73,255,77,259,76,263,81,264,88,276,96,276,103,269,103,256,100,245,100,234,62,230,61,231,71" id="El Oued" title="El Oued" href="#mapheaddiv" />
				<area  class="land" shape="poly" coords="219,70,214,72,212,83,201,97,194,132,188,139,189,144,183,148,195,158,230,136,236,137,282,124,277,102,266,103,260,101,245,101,234,62,231,61,231,70,221,72" id="Ouargla" title="Ouargla" href="#mapheaddiv" />
				<area  class="land" shape="poly" coords="212,83,201,79,186,79,188,83,171,84,171,94,171,100,164,104,166,107,166,122,164,139,167,151,184,149,188,139,195,132,201,96" id="Ghardaia" title="Ghardaïa" href="#mapheaddiv" />
	<!--40-->	<area  class="land" shape="poly" coords="150,53,158,62,162,63,166,74,170,76,166,77,171,85,171,102,163,104,148,110,140,120,127,109,133,91,137,62,132,60,137,57,136,54" id="El Bayadh" title="El Bayadh" href="#mapheaddiv" />
				<area  class="land" shape="poly" coords="133,92,137,63,132,60,129,62,127,57,123,57,120,56,114,57,107,58,108,62,107,64,109,67,108,70,108,74,111,78,110,80,118,88,115,92,119,95,123,92" id="Naama" title="Naama" href="#mapheaddiv" />
				<area  class="land" shape="poly" coords="133,92,123,93,119,94,115,92,111,94,92,94,89,96,90,100,84,104,79,103,79,107,74,113,79,116,75,117,69,121,59,121,51,134,72,155,86,181,88,164,101,154,117,151,119,153,130,138,139,119,127,109" id="Bechar" title="Béchar" href="#mapheaddiv" />
				<area  class="land" shape="poly" coords="46,211,87,181,74,157,51,135,44,136,43,135,39,139,35,136,32,140,24,140,21,143,16,142,-1,156,0,182" id="Tindouf" title="Tindouf" href="#mapheaddiv" />
				<area  class="land" shape="poly" coords="164,142,166,107,164,104,148,111,138,122,123,150,119,154,117,152,102,155,91,162,89,165,88,183,47,212,151,285,152,292,159,294,162,301,170,301,169,282,165,270,156,267,155,211,151,209,151,202,147,195,160,194,166,189,165,174,167,163,166,152" id="Adrar" title="Adrar" href="#mapheaddiv" />
				<area  class="land" shape="poly" coords="167,151,184,149,195,159,219,141,219,161,221,164,219,168,225,178,227,187,234,190,232,197,240,205,245,205,244,210,248,213,246,217,253,227,268,233,270,235,267,242,266,250,272,250,280,244,288,244,293,247,297,260,249,290,225,314,200,318,183,319,184,314,186,305,171,302,170,281,165,271,157,266,155,211,151,208,150,202,147,196,160,193,167,189,166,176" id="Tamanghasset" title="Tamanghasset" href="#mapheaddiv" />
				<area  class="land" shape="poly" coords="296,260,319,245,314,232,300,227,297,229,291,223,290,215,280,199,289,192,286,181,290,169,287,164,288,155,290,152,281,136,281,129,282,125,239,137,228,137,223,143,218,141,218,160,221,164,218,168,228,188,235,189,233,197,238,204,246,204,245,211,248,213,247,217,251,224,254,227,268,232,271,236,268,243,269,251,278,248,284,243,293,246,296,253" id="Illizi" title="Illizi" href="#mapheaddiv" />
				<area  class="land" shape="poly" coords="187,83,172,84,167,78,170,76,166,75,162,62,157,63,157,59,163,52,172,49,176,57,177,61,183,58,184,63,189,66,200,78,188,79" id="Laghouat" title="Laghouat" href="#mapheaddiv"  />
			</map>
		<img src="<?php echo JURI::root();?>media/com_m2imapselector/images/mapdz.png" width="320" height="320" usemap="#im" border="0" class="imgtag">
		</div>
		<div id="regiondetails">
			<div class="wilayaheader" class="bluecard"></div>
			<div id="region"></div>
		</div>
		<div id="pop-up" class="wilaya"  >
			
		</div>
</div>	
			
<?php
		$document = JFactory::getDocument();
		$document->addScript('media/com_m2imapselector/js/jquery-3.2.11.min.js');
		$document->addScript('media/com_m2imapselector/js/jquery.nicescroll.min.js');
		$document->addScript('media/com_m2imapselector/js/imageMapster.js');
		$document->addScript('media/com_m2imapselector/js/code.js');
?>
